^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gz_ros2_control_tests
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.21 (2026-08-31)
-------------------
* Remove linters from test stage (backport `#668 <https://github.com/ros-controls/gz_ros2_control/issues/668>`_) (`#941 <https://github.com/ros-controls/gz_ros2_control/issues/941>`_)
* Contributors: mergify[bot]

0.7.20 (2026-05-13)
-------------------
* Add missing tests for pendulum and gripper (position and effort) (backport `#814 <https://github.com/ros-controls/gz_ros2_control/issues/814>`_) (`#842 <https://github.com/ros-controls/gz_ros2_control/issues/842>`_)
* Contributors: José Luis Pérez Martín

0.7.19 (2026-04-15)
-------------------
* Add initial_value checks to state interface tests (backport `#765 <https://github.com/ros-controls/gz_ros2_control/issues/765>`_ to Humble) (`#822 <https://github.com/ros-controls/gz_ros2_control/issues/822>`_)
* Add a custom plugin for simulating actuator dynamics to the demos (backport `#693 <https://github.com/ros-controls/gz_ros2_control/issues/693>`_) (`#780 <https://github.com/ros-controls/gz_ros2_control/issues/780>`_)
* Contributors: José Luis Pérez Martín, mergify[bot]

0.7.18 (2026-01-08)
-------------------

0.7.17 (2025-09-29)
-------------------

0.7.16 (2025-08-18)
-------------------
* Provide force-torque sensor data through gz_system to controller_manager - fixes to original PR for Humble (`#637 <https://github.com/ros-controls/gz_ros2_control/issues/637>`_)
* Contributors: Bartłomiej Krajewski

0.7.15 (2025-05-23)
-------------------

0.7.14 (2025-04-21)
-------------------

0.7.13 (2025-04-04)
-------------------
* Add shim to deprecated ign_ros2_control_demos package (`#524 <https://github.com/ros-controls/gz_ros2_control/issues/524>`_)
* Backport updates to demos and tests (`#399 <https://github.com/ros-controls/gz_ros2_control/issues/399>`_, `#485 <https://github.com/ros-controls/gz_ros2_control/issues/485>`_, `#486 <https://github.com/ros-controls/gz_ros2_control/issues/486>`_, `#498 <https://github.com/ros-controls/gz_ros2_control/issues/498>`_, `#517 <https://github.com/ros-controls/gz_ros2_control/issues/517>`_) (`#522 <https://github.com/ros-controls/gz_ros2_control/issues/522>`_)
* Rename ign to gz (backport `#67 <https://github.com/ros-controls/gz_ros2_control/issues/67>`_) (`#515 <https://github.com/ros-controls/gz_ros2_control/issues/515>`_)
* Contributors: Christoph Fröhlich
